# autoEncoder01
There are two 1D CNN auto-encoders examples, they can be reconfigurable in both input and output according to your compression needs  
